"""TankAI Core."""
